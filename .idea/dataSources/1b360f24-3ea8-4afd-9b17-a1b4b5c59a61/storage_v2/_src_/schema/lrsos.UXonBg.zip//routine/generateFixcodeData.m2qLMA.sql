create
    definer = hteapp@`%` procedure generateFixcodeData(IN arr text, IN exam_year int(5), IN exam_month int(5))
P1 : BEGIN DECLARE tmp_aicode VARCHAR ( 10 ) DEFAULT NULL; 
 DECLARE inner_tmp_aicode VARCHAR ( 10 ) DEFAULT NULL; 
 DECLARE tmp_stcount INT DEFAULT 0; 
 DECLARE tmp_id INT ( 11 ) DEFAULT NULL;
 DECLARE tmp_enrollment VARCHAR ( 20 ) DEFAULT NULL;
 DECLARE b INT DEFAULT 0; DECLARE d INT DEFAULT 0;
 DECLARE aicounter INT DEFAULT 1; 
 DECLARE enrollmentcount INT DEFAULT 1;
 DECLARE loopcounterlength INT DEFAULT 1;
 DECLARE fixcodeprefix INT DEFAULT 1;
 DECLARE fixcodecount INT DEFAULT 0; 
 DECLARE fixcode VARCHAR ( 10 ) DEFAULT NULL; 
 DECLARE aicounterexist INT DEFAULT 0; 
 DECLARE i INT; 
 SET i = 1; 
 SET b = 0; 
 SET d = 0;
 SET aicounter = 1;
 SET loopcounterlength = 1; 
 SET fixcodeprefix = 1; 
 SET enrollmentcount = 1; 
 SET fixcode = ''; 
 SET aicounterexist = 0; 
 SET @str = '';
-- SET @tmp_aicode = ''; 
P2 : BEGIN 
DECLARE cur1 CURSOR FOR SELECT 
rs_student_allotments.ai_code, 
count( rs_student_allotments.enrollment ) AS student_count
 FROM rs_student_allotments 
 WHERE ( 
-- rs_student_allotments.deleted_at IS NULL 
rs_student_allotments.exam_year = exam_year 
AND rs_student_allotments.exam_month = exam_month ) 
GROUP BY rs_student_allotments.ai_code 
ORDER BY student_count DESC;

DECLARE cur2 CURSOR FOR SELECT 
rs_student_allotments.id, 
rs_student_allotments.enrollment 
FROM rs_student_allotments 
 WHERE 
( -- rs_student_allotments.deleted_at IS NULL 
rs_student_allotments.exam_year = exam_year 
AND rs_student_allotments.exam_month = exam_month
AND rs_student_allotments.ai_code = tmp_aicode COLLATE utf8_unicode_ci ); 

DECLARE CONTINUE HANDLER FOR NOT FOUND SET b = 1;
-- DECLARE CONTINUE HANDLER FOR NOT FOUND SET d=1; 
OPEN cur1;
-- REPEAT
 aicode_loop : LOOP FETCH cur1 INTO tmp_aicode, tmp_stcount;
 IF b = 1 THEN 
 CLOSE cur1;
 LEAVE aicode_loop;
 END IF; 
 SELECT FIND_IN_SET( aicounter, arr ) INTO aicounterexist;
 IF aicounterexist > 0 THEN SET aicounter = aicounter + 1;
 END IF;
 SET loopcounterlength = LENGTH( CONVERT ( aicounter, CHAR ));
 IF loopcounterlength = 1 THEN SET fixcodeprefix = aicounter * 100000; 
 END IF; 
 IF loopcounterlength = 2 THEN SET fixcodeprefix = aicounter * 10000; 
  END IF; IF loopcounterlength = 3 THEN 
  SET fixcodeprefix = aicounter * 1000; 
  END IF;
  -- CALL updateFixcodeData(tmp_aicode,exam_year,exam_month); 
  P3 : BEGIN 
  SET enrollmentcount = 1; 
  OPEN cur2;
  -- REPEAT 
  student_loop : LOOP FETCH cur2 INTO tmp_id,tmp_enrollment;
  IF b = 1 THEN SET b = 0;
  CLOSE cur2; 
  LEAVE student_loop;
  END IF; 
  SET fixcode =( fixcodeprefix + enrollmentcount ); 
  P4 : BEGIN
  -- SELECT COUNT(*) FROM -- rs_student_allotments 
  -- WHERE 
  -- ( -- rs_student_allotments.deleted_at IS NULL 
  -- rs_student_allotments.exam_year = exam_year 
  -- AND rs_student_allotments.exam_month = exam_month
  -- AND rs_student_allotments.fixcode2 = @fixcode COLLATE utf8mb4 
  -- ) INTO fixcodecount; 
  -- IF fixcodecount <= 0 THEN 
  UPDATE rs_student_allotments SET fixcode2 = fixcode,fixcode = fixcode WHERE id = tmp_id;
  -- END IF;
  -- SET @str = CONCAT(@str,tmp_aicode,' ');
  END P4;
  -- END; 
  SET enrollmentcount = enrollmentcount + 1;
  -- SET d=0;
  END LOOP;
  -- UNTIL d END REPEAT;
  -- CLOSE cur2; 
  END P3; 
  SET aicounter = aicounter + 1;
  -- SET b=0;
  END LOOP; 
  SELECT @str AS NCOUNTER;
  -- UNTIL b END REPEAT;
  -- CLOSE cur1; 
  END P2; 
  END P1;

