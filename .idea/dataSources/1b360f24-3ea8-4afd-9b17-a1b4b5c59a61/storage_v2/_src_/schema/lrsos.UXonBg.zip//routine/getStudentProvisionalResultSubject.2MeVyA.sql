create
    definer = root@`%` procedure getStudentProvisionalResultSubject(IN student_id int(11) unsigned, IN exam_year int, IN exam_month int)
SELECT es.student_id, es.subject_id, es.final_theory_marks, es.sessional_marks_reil_result, es.final_practical_marks, es.total_marks, es.final_result FROM `rs_provisional_exam_subjects` es INNER JOIN rs_subjects s ON s.id = es.subject_id WHERE es.student_id = student_id AND es.exam_year = exam_year AND es.exam_month = exam_month AND es.final_result != "" AND es.deleted_at IS NULL GROUP BY s.subject_code ORDER BY s.subject_code ASC, es.exam_year DESC, es.exam_month DESC;

