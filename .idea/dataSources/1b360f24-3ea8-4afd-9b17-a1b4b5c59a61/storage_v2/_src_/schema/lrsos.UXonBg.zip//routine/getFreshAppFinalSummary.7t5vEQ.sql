create
    definer = hteapp@`%` procedure getFreshAppFinalSummary(IN exam_year int, IN course int, IN stream int,
                                                           IN locksumbitted int, IN is_eligible int, IN isonlyissue int,
                                                           IN startlimitinput int, IN endlimitinput int)
BEGIN
	
	SET is_eligible = COALESCE (
		IF
		( is_eligible IN ( '0', '1' ), is_eligible, '2' ));
	
	SET locksumbitted = COALESCE (
		IF
		( locksumbitted IN ( '0', '1' ), locksumbitted, '2' ));
	SET startlimitinput = COALESCE (
		IF
		( startlimitinput > 0, startlimitinput, '0' ));
	SET endlimitinput = COALESCE (
		IF
		( endlimitinput > 0, endlimitinput, '500000' ));
	DROP TABLE
	IF
		EXISTS temp_view;
	DROP TABLE
	IF
		EXISTS temp_view_two;
	CREATE TABLE temp_view AS SELECT-- count(s.id) as totalcount,
	( CASE WHEN s.is_eligible = 1 THEN 'Yes' ELSE 'No' END ) AS `Eligible`,
	( CASE WHEN app.locksumbitted = 1 THEN 'Yes' ELSE 'No' END ) AS `Is Lock Submitted`,
	s.enrollment AS `Enrollment`,
	s.id AS `Student Id`,
	s.NAME AS `Name`,
	s.ssoid AS `SSO`,
	s.dob AS `DOB`,
	s.challan_tid AS `Challan Number`,

(
case 
	when app.disability = 1 then "Kodh/Kusht"
	when app.disability = 2 then "Dumb"
	when app.disability = 3 then "Blind"
	when app.disability = 4 then "Mental Disable"
	when app.disability = 5 then "Physical Disability"
	when app.disability = 6 then "Hand Leg Related"
	when app.disability = 7 then "Autism"
	when app.disability = 8 then "Dyslexic"
	when app.disability = 9 then "Spastic"
	when app.disability = 10 then "Not Applicable"
	else 	'N/A'
end ) as `Disablity`, 	
	(
	case
	when app.disadvantage_group = 1 then "BPL Card Holder"
	when app.disadvantage_group = 2 then "Other"
	when app.disadvantage_group = 3 then "Not Applicable"
	when app.disadvantage_group = 4 then "Females of Jhalawar Mahila Shikshan Vihar"
	when app.disadvantage_group = 5 then "Residents of Rajasthan Registered Orphanages"
	when app.disadvantage_group = 6 then "Students of Registered Juvenile Homes"
	when app.disadvantage_group = 7 then "Students of Ghumantu Category"
	else 	'N/A'
	end
) as `Disadvantage`, 
	(
	case
	when app.category_a = 1 then "GEN"
	when app.category_a = 2 then "SC"
	when app.category_a = 3 then "ST"
	when app.category_a = 4 then "SOBC"
	when app.category_a = 5 then "OBC"
	when app.category_a = 6 then "EX-Serv."
	when app.category_a = 7 then "Jail In Mate"
	else 	'N/A'
	end
) as `Category A`, 
(
	case
	when s.adm_type = 1 then "General Admission" 
	when s.adm_type = 2 then "Re-admission" 
	when s.adm_type = 3 then "Part Admission"
	when s.adm_type = 4 then "Improvement"
	when s.adm_type = 5 then "ITI"
	else 	'N/A'
	end
) as `Admision Type`, 

	
	( CASE WHEN s.course = 10 THEN '10th' WHEN s.course = 12 THEN '12th' ELSE 'No' END ) AS `Course`,
	( CASE WHEN s.stream = 1 THEN 'Stream-I' WHEN s.stream = 2 THEN 'Stream-II' ELSE 'No' END ) AS `Stream`,
	( CASE WHEN s.are_you_from_rajasthan = 1 THEN 'Yes' ELSE 'No' END ) AS `Is Rajasthan`,
	s.application_fee_date AS `Applicaiton Fee Date`,
	app.fee_paid_amount AS `Fee Paid Amount`,
	( CASE WHEN s.gender_id = 1 THEN 'Male' WHEN s.gender_id = 2 THEN 'Female' ELSE 'Other' END ) AS `Gender`,
	( CASE WHEN app.toc = 1 THEN 'Yes' ELSE 'No' END ) AS `Is Toc`,
	sf.total AS `Fees Total`,
	( SELECT count( id ) FROM rs_admission_subjects WHERE deleted_at IS NULL AND student_id = s.id ) AS `Admission Subject Count`,
	( SELECT count( id ) FROM rs_admission_subjects WHERE deleted_at IS NULL AND student_id = s.id ) AS `Exam Subject Count`,
	( SELECT count( id ) FROM rs_toc_marks WHERE deleted_at IS NULL AND student_id = s.id ) AS `TOC Subject Count`,
	sf.id AS `Fees Id`,
	app.id AS `App Id`,
	adr.id AS `Address Id`,
	bank.id AS `Bank Id`,
	pi.id AS `Payment Issue Id`,
	IF
		( ( SELECT count( id ) FROM rs_admission_subjects WHERE deleted_at IS NULL AND student_id = s.id ) > 0, 'Yes', 'No' ) AS `Is Valid Admission Subject`,
	IF
		( ( SELECT count( id ) FROM rs_admission_subjects WHERE deleted_at IS NULL AND student_id = s.id ) > 0, 'Yes', 'No' ) AS `Is Valid Exam Subject`,
	IF
		(
			app.toc = 1,
		IF
			( ( SELECT count( id ) FROM rs_admission_subjects WHERE deleted_at IS NULL AND student_id = s.id ) > 0, 'Yes', 'No' ),
			'Yes' 
		) AS `Is Valid Toc Subject`,
	IF
		( sf.id > 0, 'Yes', 'No' ) AS `Is Valid Fees`,
	IF
		( app.id > 0, 'Yes', 'No' ) AS `Is Valid App`,
	IF
		( adr.id > 0, 'Yes', 'No' ) AS `Is Valid Address`,
	IF
		( bank.id > 0, 'Yes', 'No' ) AS `Is Valid Bank` 
	FROM
		rs_students s
		LEFT JOIN rs_applications app ON app.student_id = s.id 
		AND app.deleted_at
		IS NULL LEFT JOIN rs_student_fees sf ON sf.student_id = s.id 
		AND sf.deleted_at
		IS NULL LEFT JOIN rs_addresses adr ON adr.student_id = s.id 
		AND adr.deleted_at
		IS NULL LEFT JOIN rs_bank_details bank ON bank.student_id = s.id 
		AND bank.deleted_at
		IS NULL LEFT JOIN rs_payment_issues pi ON pi.student_id = s.id 
		AND pi.deleted_at IS NULL 
	WHERE
		s.exam_year = exam_year 
	AND
	IF
		( course > 0, s.course = course, 1 = 1 ) 
	AND
	IF
		( stream > 0, s.stream = stream, 1 = 1 ) 
	AND
	IF
		( is_eligible IN ( 0, 1 ), s.is_eligible = is_eligible, 1 = 1 ) -- send 2 if all wants
		
	AND
	IF
		( locksumbitted IN ( 0, 1 ), app.locksumbitted = locksumbitted, 1 = 1 ) -- send 2 if all wants
		
		AND s.deleted_at IS NULL 
		LIMIT startlimitinput,endlimitinput;
	DROP TABLE
	IF
		EXISTS temp_view_two;
	CREATE TABLE temp_view_two AS SELECT
	IF
		(
			(
				`Is Valid Fees` = 'No' || `Is Valid App` = 'No' || `Is Valid Address` = 'No' || `Is Valid Bank` = 'No' || `Is Valid Toc Subject` = 'No' || `Is Valid Admission Subject` = 'No' || `Is Valid Exam Subject` = 'No' 
			),
			'No',
			'Yes' 
		) AS `Is Valid Final Status`,
		tv.* 
	FROM
		temp_view AS tv 
	ORDER BY
		`Is Valid Final Status`,
		tv.`Student Id`;-- Drop the view
	DROP TABLE
	IF
		EXISTS temp_view;
	SELECT
		* 
	FROM
		temp_view_two 
	WHERE
	IF
		( isonlyissue IN ( 1 ), `Is Valid Final Status` = 'No', 1 = 1 ) 
	AND
	IF
		( isonlyissue IN ( 1 ), `Eligible` = 'Yes', 1 = 1 );
	DROP TABLE
	IF
		EXISTS temp_view_two;

END;

