create
    definer = hteapp@`%` procedure getFreshVerificaitonSummary(IN exam_year int, IN exam_month int, IN course int,
                                                               IN ai_codes varchar(255))
BEGIN
	 
	
	 SELECT
	ac.ssoid AS `aicenter_ssoid`,
	s.ssoid AS `student_ssoid`,
	( CASE WHEN s.is_eligible = 1 THEN "Yes" ELSE "No" END ) AS `Is Eligible`,
	s.id,
	s.enrollment,
	s.exam_year,
	s.exam_month,
	s.course,
	s.ai_code,
	s.student_code,
	(
	CASE
			WHEN s.is_doc_rejected = 1 THEN
			"Yes"
			WHEN s.is_doc_rejected != 1 THEN
			"No" 
		END ) as `Is Doc Rejected`,
	( CASE WHEN a.is_ready_for_verifying = 1 THEN "Yes" ELSE "No" END ) AS `Is Allow For Verify`,
	(
	CASE
			
			WHEN s.verifier_status = 1 THEN
			"Pending" 
			WHEN s.verifier_status = 2 THEN
			"Approved" 
			WHEN s.verifier_status = 3 THEN
			"Rejected" 
			WHEN s.verifier_status = 4 THEN
			"Clarification Received"			
			WHEN s.verifier_status = 5 THEN
			"Verifier Request To Department"			
			WHEN s.verifier_status = 6 THEN
			"Department Sent Clarification To Verifier" 
		END 
		) AS `Ai Center Status`,
		(
		CASE
				WHEN (s.verifier_status = 2) THEN
				"No need already approved by verifier" 
				WHEN (s.verifier_status != 2 && s.department_status = 1) THEN
				"Pending" 
				WHEN s.department_status = 2 THEN
				"Approved" 
				WHEN s.department_status = 3 THEN
				"Rejected" 
				WHEN s.department_status = 4 THEN
				"Clarification Received" 
			END 
			) AS `Department Status`,
			(
			CASE
					
					WHEN ( sv.challan_tid IS NOT NULL ) THEN
					"Payment Received" 
					WHEN ( s.department_status = 3 AND sv.challan_tid IS NULL ) THEN
					"Payment Not Received" ELSE "Other" 
				END 
				) AS `Student Clarification Payment Status`,
				(
				CASE
						
						WHEN s.verifier_status IN ( 1, 4, 6 ) THEN
						'Aicenter' 
						WHEN s.verifier_status IN ( 5 ) THEN
						'Department Basic Details Pending' 
						WHEN s.department_status IN ( 1, 4 ) THEN
						'Department' 
						WHEN ( s.verifier_status IN ( 3 ) OR s.department_status IN ( 3 ) ) THEN
						'Student' 
						WHEN ( s.verifier_status IN ( 2 ) OR s.department_status IN ( 2 ) ) THEN
						'Completed' ELSE "Other" 
					END 
					) AS `Work Pending At` 
				FROM
					rs_students s
					INNER JOIN rs_applications a ON a.student_id = s.id
					LEFT JOIN rs_student_verifications sv ON sv.student_id = s.id
					INNER JOIN rs_aicenter_details ac ON ac.ai_code = s.ai_code 
				WHERE
					s.exam_year = exam_year
					AND IF(exam_month > 0,s.exam_month = exam_month,1=1)
					AND IF(course > 0,s.course = course,1=1)
					AND s.deleted_at IS NULL 
					and if(ai_codes > 0,s.ai_code in (ai_codes),1=1)
			ORDER BY
	s.id; 
END;

