create
    definer = root@`%` procedure setProvisionalSubjectAndResult(IN exam_year varchar(11), IN exam_month varchar(11))
BEGIN
	 
drop table if exists rs_provisional_exam_subjects;
drop table if exists rs_provisional_exam_results;
create table rs_provisional_exam_subjects select * from rs_exam_subjects where exam_year = 125 and exam_month = 1 and deleted_at is null;
create table rs_provisional_exam_results  select * from rs_exam_results where exam_year = 125 and exam_month = 1 and deleted_at is null;
ALTER TABLE `rs_provisional_exam_subjects` 
ADD INDEX `student_id`(`student_id`),
ADD INDEX `exam_year`(`exam_year`),
ADD INDEX `subject_id`(`subject_id`),
ADD INDEX `exam_month`(`exam_month`);

ALTER TABLE `rs_provisional_exam_results` 
ADD INDEX `student_id`(`student_id`),
ADD INDEX `exam_year`(`exam_year`),
ADD INDEX `exam_month`(`exam_month`);

END;

