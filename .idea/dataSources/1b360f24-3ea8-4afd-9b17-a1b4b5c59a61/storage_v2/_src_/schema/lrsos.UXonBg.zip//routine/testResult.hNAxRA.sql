create
    definer = hteapp@`%` procedure testResult(IN exam_year varchar(100), IN exam_month varchar(100))
BEGIN 


DROP TABLE IF EXISTS blah;

CREATE TEMPORARY TABLE `blah` ( QUERY VARCHAR ( 255 ), count VARCHAR ( 11 ), STATUS VARCHAR ( 11 ) );
-- Test1 
SET @x :=1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where final_result = ' ' and toc!=1; 
-- Test2 
SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where total_marks>100; 
-- Test3 
SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where theory_marks>100 and practical_marks>100 and final_result='P';
 -- Test4 
SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where theory_marks>100 and final_result='P' and course!=10;
 -- Test5
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where practical_marks>100 and final_result='P' and subject_id in(23,24,25,28,33,35,37,38,39); 
-- Test6 
SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where sessional_marks_reil_result=0 and toc=0 and is_supplementary!=1 and is_th_sess_updated=0; 
-- Test7
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in (18,19,20,21,22,26,27,29,31,32,34,36) and (sessional_marks_reil_result+theory_marks)<33 and final_result='P' and is_grace_marks_given!=1;
 -- Test8
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in (18,19,20,21,22,26,27,29,31,32,34,36) and (sessional_marks_reil_result+theory_marks)>=33 and theory_marks<100 and final_result='SYC'; 
 -- Test9 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in (23,24,25,28,33,38) and (sessional_marks_reil_result+theory_marks)>=26 and practical_marks>7 and theory_marks<100 and practical_marks<100 and final_result='SYC'; 
 -- Test10 
SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in (23,24,25,28,33,38) and (sessional_marks_reil_result+theory_marks)<=26 and practical_marks>7 and theory_marks<100 and practical_marks<100 and final_result='SYC'; 
-- Test11 
SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in (23,24,25,28,33,38) and (sessional_marks_reil_result+theory_marks)<=26 and practical_marks>7 and theory_marks<100 and practical_marks<100 and final_result='SYCP'; 
-- Test12 
SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in (23,24,25,28,33,38) and (sessional_marks_reil_result+theory_marks)>=26 and practical_marks<7 and theory_marks<100 and practical_marks<100 and final_result='SYC'; 
-- Test13 
SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in (23,24,25,28,33,38) and (sessional_marks_reil_result+theory_marks)>=26 and practical_marks<7 and theory_marks<100 and practical_marks<100 and final_result='SYCT'; 
-- Test14 
SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in (35) and (sessional_marks_reil_result+theory_marks)>=20 and practical_marks>13 and theory_marks<100 and practical_marks<100 and final_result='SYC'; 
-- Test15 
SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in (35) and (sessional_marks_reil_result+theory_marks)<= 20 and practical_marks>13 and theory_marks<100 and practical_marks<100 and final_result='SYC';
 -- Test16 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in (35) and (sessional_marks_reil_result+theory_marks)<= 20 and practical_marks>13 and theory_marks<100 and practical_marks<100 and final_result='SYCP'; 
 -- Test17 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in (35) and (sessional_marks_reil_result+theory_marks)>= 20 and practical_marks<13 and theory_marks<100 and practical_marks<100 and final_result='SYC';
 -- Test18
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in (35) and (sessional_marks_reil_result+theory_marks)>= 20 and practical_marks<13 and theory_marks<100 and practical_marks<100 and final_result='SYCT'; 
 -- Test19 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in (39) and (sessional_marks_reil_result+theory_marks)>=13 and practical_marks>20 and theory_marks<100 and final_result='SYC'; -- Test20 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in (39) and (sessional_marks_reil_result+theory_marks)<= 13 and practical_marks>20 and theory_marks<100 and practical_marks<100 and final_result='SYC'; 
 -- Test21 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in (39) and (sessional_marks_reil_result+theory_marks)<= 13 and practical_marks>20 and theory_marks<100 and practical_marks<100 and final_result='SYCP'; 
 -- Test22 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in (39) and (sessional_marks_reil_result+theory_marks)>= 13 and practical_marks<20 and theory_marks<100 and practical_marks<100 and final_result='SYC';
 -- Test23 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in (39) and (sessional_marks_reil_result+theory_marks)>= 13 and practical_marks<20 and theory_marks<100 and practical_marks<100 and final_result='SYCT'; 
 -- Test24 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in (37) and (sessional_marks_reil_result+theory_marks)>= 10 and practical_marks>23 and theory_marks<100 and final_result='SYC';
 -- Test25 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in (37) and (sessional_marks_reil_result+theory_marks)<=10 and practical_marks>23 and theory_marks<100 and practical_marks<100 and final_result='SYC'; 
 -- Test26 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in (37) and (sessional_marks_reil_result+theory_marks)<= 10 and practical_marks>23 and theory_marks<100 and practical_marks<100 and final_result='SYCP'; 
 -- Test27 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in (37) and (sessional_marks_reil_result+theory_marks)>= 10 and practical_marks<23 and theory_marks<100 and practical_marks<100 and final_result='SYC'; 
 -- Test28 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in (37) and (sessional_marks_reil_result+theory_marks)>= 10 and practical_marks<23 and theory_marks<100 and practical_marks<100 and final_result='SYCT'; 
 -- Test29 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in( 23,24,25,28,33,38) and (sessional_marks_reil_result+theory_marks)>80 and theory_marks<100; 
 -- Test30 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in( 23,24,25,28,33,38) and practical_marks>20 and practical_marks<100 AND toc!=1;
 -- Test31 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in(35) and (sessional_marks_reil_result+theory_marks)>60 and theory_marks<100; 
 -- Test32 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in(35) and practical_marks>40 and practical_marks<100;
 -- Test33 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in(39) and (sessional_marks_reil_result+theory_marks)>40 and theory_marks<100;
 -- Test34 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in(39) and practical_marks>60 and practical_marks<100;
 -- Test35 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in(37) and (sessional_marks_reil_result+theory_marks)>30 and sessional_marks_reil_result!=999 and theory_marks<100;
 -- Test36 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in(37) and practical_marks>70 and practical_marks<100; 
 -- Test37 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where final_result is NULL; 
 -- Test38 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where total_marks>100; 
 -- Test39 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where theory_marks>100 and practical_marks>100 and final_result='P'; 
 -- Test40 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in(1,2,9,10,11,6,41,5,12,30,17,40) and (sessional_marks_reil_result)>10 and sessional_marks_reil_result<100 and is_supplementary!=1; 
 -- Test41 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in(1,2,9,10,11,6,41,5,12,30,17,40) and theory_marks>100 AND theory_marks!=999 AND is_supplementary=1;
 -- Test42 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in(4,3,13) and (sessional_marks_reil_result)>9 and sessional_marks_reil_result<100; 
 -- Test43 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in(4,3,13) and (theory_marks )>76 and theory_marks<100 and is_supplementary!=1; 
 -- Test44 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in(4,3,13) and (theory_marks )>85 and theory_marks<100 and is_supplementary=1; 
 -- Test45 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in(4,3,13) and (practical_marks)>15 and practical_marks <100 AND toc!=1; 
 -- Test46 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in(16) and sessional_marks_reil_result>3 and sessional_marks_reil_result!=999 AND is_supplementary!=1; 
 -- Test47 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in(16) and theory_marks>27 and theory_marks<100 AND is_supplementary!=1;
 -- Test48 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in(16) and theory_marks >30 and theory_marks<100 AND is_supplementary=1; 
 -- Test49 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in(16) and (practical_marks)>70 and practical_marks <100; 
 -- Test50 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id=7 and sessional_marks_reil_result>4 and sessional_marks_reil_result!=999 AND is_supplementary!=1 ;
 -- Test51 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in(7) and (theory_marks )>36 and theory_marks<100 AND is_supplementary!=1; 
 -- Test52 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in(7) and (theory_marks )>40 and theory_marks<100 AND is_supplementary=1;
 -- Test53 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in(7) and (practical_marks)>60 and practical_marks <100; 
 -- Test54 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in(1,2,9,10,11,6,41,5,12,30,17,40) and (sessional_marks_reil_result+theory_marks)<33 and final_result='P' and is_grace_marks_given!=1 ;
 -- Test55 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in(4,3,13,16,7) and (sessional_marks_reil_result+theory_marks+practical_marks)<33 and final_result='P' and is_grace_marks_given!=1;
 --	Test56 
 SET @x = @x + 1; INSERT INTO blah(query,count,status) select concat ('Test-',@x),count(id), if(count(id) = 0,'Pass','Fail') from rs_prepare_exam_subjects where subject_id in(1,2,9,10,11,6,41,5,12,30,17,40) and theory_marks>90 and theory_marks<100 and is_supplementary!=1 AND toc!=1;
 -- test57 
 SET @x = @X + 1; INSERT INTO blah(query,count,status) select concat ('Test-mm-',@x),count(pes.id), if(count(pes.id) = 0,'Pass','Fail') from rs_prepare_exam_subjects as pes inner join rs_prepare_exam_results as enr on pes.student_id=enr.student_id inner join rs_students as s on pes.student_id=s.id WHERE s.adm_type!=5 and pes.final_result='P' and enr.final_result='PASS' group by pes.student_id having count(pes.student_id)<=4; SELECT * FROM blah order by status; DROP TEMPORARY TABLE blah; 
 

END;

