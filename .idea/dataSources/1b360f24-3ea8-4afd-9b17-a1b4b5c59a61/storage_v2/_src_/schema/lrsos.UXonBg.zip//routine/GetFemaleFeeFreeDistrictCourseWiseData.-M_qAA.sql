create
    definer = hteapp@`%` procedure GetFemaleFeeFreeDistrictCourseWiseData()
BEGIN
    -- Temporary table to store intermediate results for optimization
    CREATE TEMPORARY TABLE tmp_district_data (
        district_name VARCHAR(255),
        tenth_count INT DEFAULT 0,
        twelfth_count INT DEFAULT 0,
        total_count INT DEFAULT 0
    );
    
    -- Insert the query results into the temporary table
    INSERT INTO tmp_district_data (district_name, tenth_count, twelfth_count, total_count)
    SELECT 
        d.name AS district_name, 
        SUM(CASE WHEN s.are_you_from_rajasthan = 1 AND sf.total <= 0 AND s.course = 10 THEN 1 ELSE 0 END) AS tenth_count,
        SUM(CASE WHEN s.are_you_from_rajasthan = 1 AND sf.total <= 0 AND s.course = 12 THEN 1 ELSE 0 END) AS twelfth_count,
        SUM(CASE WHEN s.are_you_from_rajasthan = 1 AND sf.total <= 0 THEN 1 ELSE 0 END) AS total_count
    FROM rs_aicenter_details ad
    INNER JOIN rs_districts d 
        ON ad.district_id = d.id
    LEFT JOIN rs_students s 
        ON ad.ai_code = s.ai_code 
        AND s.gender_id = 2 
        AND s.exam_year = 126 
        AND s.deleted_at IS NULL
    LEFT JOIN rs_student_fees sf 
        ON sf.student_id = s.id 
        AND sf.deleted_at IS NULL
    WHERE 
        ad.is_allow_for_admission = 1
    GROUP BY 
        ad.district_id, d.name;

    -- Select results from temporary table
    SELECT * FROM tmp_district_data
    ORDER BY district_name;

    -- Drop temporary table after use
    DROP TEMPORARY TABLE IF EXISTS tmp_district_data;
END;

