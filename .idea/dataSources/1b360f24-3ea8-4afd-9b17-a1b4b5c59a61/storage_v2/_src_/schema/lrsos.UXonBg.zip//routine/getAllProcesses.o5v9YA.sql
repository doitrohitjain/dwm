create
    definer = hteapp@`%` procedure getAllProcesses()
BEGIN
    SELECT ID, USER, HOST, DB, COMMAND, TIME, STATE, INFO
    FROM INFORMATION_SCHEMA.PROCESSLIST;
END;

