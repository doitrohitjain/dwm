create
    definer = hteapp@`%` procedure killAllProcesses()
BEGIN
    DECLARE done INT DEFAULT 0;
    DECLARE process_id INT;
    DECLARE process_cursor CURSOR FOR
        SELECT ID
        FROM INFORMATION_SCHEMA.PROCESSLIST
        WHERE ID != CONNECTION_ID() AND USER != 'system user';

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

    OPEN process_cursor;

    read_loop: LOOP
        FETCH process_cursor INTO process_id;
        IF done THEN
            LEAVE read_loop;
        END IF;
        SET @kill_query = CONCAT('KILL ', process_id);
        PREPARE stmt FROM @kill_query;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END LOOP;

    CLOSE process_cursor;
END;

