create
    definer = hteapp@`%` procedure _Navicat_Temp_Stored_Proc(IN exam_year varchar(100), IN exam_month varchar(100))
    DROP TABLE IF EXISTS blah;

