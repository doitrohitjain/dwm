create
    definer = hteapp@`%` procedure enterDataIntoStudentAllotmentMarks(IN maxLimit int, IN examyear int, IN exammonth int)
BEGIN
	INSERT INTO `rs_student_allotment_marks` (
		`is_supplementary`,
		`enrollment`,
		`course`,
		`user_id`,
		`ai_code`,
		`student_id`,
		`subject_id`,
		`subject_name`,
		`subject_code`,
		`stream`,
		`exam_year`,
		`exam_month`,
		`student_allotment_id`,
		`examcenter_detail_id`,
		`fixcode`,
		`ai_code_district_id`,
		`theory_max_marks`,
		`practical_max_marks` 
	) SELECT
	0,
	s.enrollment,
	s.course,
	s.user_id,
	s.ai_code,
	s.id AS student_id,
	es.subject_id,
	su.real_name,
	su.subject_code,
	s.stream,
	s.exam_year,
	s.exam_month,
	sa.id,
	sa.examcenter_detail_id,
	sa.fixcode,
	u.district_id,
	su.theory_max_marks,
	su.practical_max_marks 
	FROM
		rs_exam_subjects es
		INNER JOIN rs_students s ON es.student_id = s.id
		LEFT JOIN rs_aicenter_details u ON s.user_id = u.user_id
		INNER JOIN rs_student_allotments sa ON sa.student_id = es.student_id 
		AND sa.exam_year = examyear 
		AND sa.exam_month = exammonth
		INNER JOIN rs_subjects su ON su.id = es.subject_id 
	WHERE
		s.exam_year = examyear 
		AND s.exam_month = exammonth 
		AND es.exam_year = examyear 
		AND es.exam_month = exammonth 
		AND es.deleted_at IS NULL 
		AND s.deleted_at IS NULL 
		AND sa.deleted_at IS NULL 
	GROUP BY
		es.student_id,
		es.subject_id 
	ORDER BY
		s.id 
		LIMIT maxLimit;
	INSERT INTO `rs_student_allotment_marks` (
		`is_supplementary`,
		`enrollment`,
		`course`,
		`user_id`,
		`ai_code`,
		`student_id`,
		`subject_id`,
		`subject_name`,
		`subject_code`,
		`stream`,
		`exam_year`,
		`exam_month`,
		`student_allotment_id`,
		`examcenter_detail_id`,
		`fixcode`,
		`ai_code_district_id`,
		`theory_max_marks`,
		`practical_max_marks` 
	) SELECT
	1,
	supp.enrollment,
	supp.course,
	supp.user_id,
	supp.ai_code,
	es.student_id,
	es.subject_id,
	su.real_name,
	su.subject_code,
	supp.stream,
	supp.exam_year,
	supp.exam_month,
	sa.id,
	sa.examcenter_detail_id,
	sa.fixcode,
	u.district_id,
	su.theory_max_marks,
	su.practical_max_marks 
	FROM
		rs_supplementary_subjects es
		INNER JOIN rs_supplementaries supp ON supp.student_id = es.student_id
		LEFT JOIN rs_aicenter_details u ON supp.user_id = u.user_id
		INNER JOIN rs_student_allotments sa ON sa.student_id = es.student_id 
		AND sa.exam_year = examyear 
		AND sa.exam_month = exammonth 
		AND supp.challan_tid
		IS NOT NULL INNER JOIN rs_subjects su ON su.id = es.subject_id 
	WHERE
		supp.is_eligible = 1 
		AND supp.exam_year = examyear 
		AND supp.exam_month = exammonth 
		AND es.exam_year = examyear 
		AND es.exam_month = exammonth 
		AND es.deleted_at IS NULL 
		AND supp.deleted_at IS NULL 
		AND sa.deleted_at IS NULL 
	GROUP BY
		es.student_id,
		es.subject_id 
	ORDER BY
		es.student_id 
		LIMIT maxLimit;
	
	SELECT
		COUNT( id ) 
	FROM
		rs_student_allotment_marks 
	WHERE
		exam_year = examyear 
		AND exam_month = exammonth;

END;

