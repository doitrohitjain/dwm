create
    definer = hteapp@`%` procedure setProvisionalSubjectAndResult(IN exam_year varchar(11), IN exam_month varchar(11))
    drop table if exists rs_provisional_exam_subjects;

