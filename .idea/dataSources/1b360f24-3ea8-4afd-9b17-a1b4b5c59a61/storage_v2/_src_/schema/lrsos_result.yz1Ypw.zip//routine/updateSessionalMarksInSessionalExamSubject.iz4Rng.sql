create
    definer = hteapp@`%` procedure updateSessionalMarksInSessionalExamSubject(IN examyear int, IN exammonth int,
                                                                              IN stid int, IN subjid int(3),
                                                                              IN sessional_marks int(3),
                                                                              IN is_sessional_mark_entered int(1))
BEGIN

SET SQL_SAFE_UPDATES=0;
UPDATE `rs_sessional_exam_subjects` SET `sessional_marks`=sessional_marks,`sessional_marks_reil_result`=sessional_marks,`is_sessional_mark_entered`=is_sessional_mark_entered WHERE `student_id`=stid AND `subject_id`=subjid AND `exam_year` = examyear AND `exam_month`= exammonth;

END;

