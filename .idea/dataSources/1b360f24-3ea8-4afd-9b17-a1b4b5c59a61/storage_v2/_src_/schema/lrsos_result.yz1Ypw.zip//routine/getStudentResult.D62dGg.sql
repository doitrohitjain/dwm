create
    definer = hteapp@`%` procedure getStudentResult(IN enrollment varchar(255), IN dob varchar(255), IN exam_year int,
                                                    IN exam_month int)
SELECT `rs_exam_results`.`enrollment`, `rs_exam_results`.`student_id`, `rs_exam_results`.`total_marks`, `rs_students`.`exam_month`, `rs_students`.`name`, `rs_students`.`father_name`, `rs_students`.`mother_name`, `rs_students`.`dob`, `rs_students`.`course`, `rs_exam_results`.`additional_subjects`, `rs_exam_results`.`final_result`, `rs_students`.`stream`,`rs_exam_results`.`revised` FROM `rs_exam_results` INNER JOIN `rs_students` ON `rs_students`.`id` = `rs_exam_results`.`student_id` WHERE ( `rs_exam_results`.`deleted_at` IS NULL AND `rs_exam_results`.`final_result` IS NOT NULL AND `rs_exam_results`.`enrollment` = enrollment AND `rs_exam_results`.`exam_year` = exam_year AND `rs_exam_results`.`exam_month` = exam_month AND `rs_students`.`dob` = dob ) LIMIT 1;

